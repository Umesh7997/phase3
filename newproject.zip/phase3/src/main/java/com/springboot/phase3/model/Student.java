package com.springboot.phase3.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name = "student")                         ///table name in database
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "first_name")                        ////first name
	private String firstName;

	@Column(name = "last_name")                        /////second name
	private String lastName;
	
	@Column(name = "email_id")                        /////email id
	private String emailId;
	
	public Student() {
		
	}
	public long getId() {                              ///get id
		return id;
	}
	public void setId(long id) {                      /// set id
		this.id = id;
	}
	public String getFirstName() {                    //// get first name
		return firstName;
	}
	public void setFirstName(String firstName) {         //// set first name
		this.firstName = firstName;
	}
	public String getLastName() {                       //// get last name
		return lastName;
	}
	public void setLastName(String lastName) {          //// set last name
		this.lastName = lastName;
	}
	public String getEmailId() {                        ///get email id
		return emailId;
	}
	public void setEmailId(String emailId) {              ///set email id
		this.emailId = emailId;
	}
}
